//
//  ViewController.swift
//  ChangeColorOfText
//
//  Created by  on 11/3/16.
//  Copyright © 2016 UHCL. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var theLabel: UILabel!
    
    @IBOutlet weak var myText: UITextField!
    @IBAction func apply(sender: UIButton) {
        let myMutableString = NSMutableAttributedString(string: myText.text!)
        myMutableString.addAttribute(NSForegroundColorAttributeName, value: UIColor.redColor(), range: NSRange(location:2, length: 3))
        theLabel.attributedText = myMutableString
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

