//
//  ViewController.swift
//  FirstApp
//
//  Created by  on 9/8/16.
//  Copyright © 2016 UHCL. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
    @IBOutlet weak var welcomeText: UITextField!

    @IBOutlet weak var greetingChoice: UISegmentedControl!
    
    @IBOutlet weak var theImage: UIImageView!
    
    @IBOutlet weak var buttonImg: UIImageView!
    
    @IBAction func greet(sender: UIButton) {
        //changes the color of button text to red color
        sender.setTitleColor(UIColor.redColor(), forState: .Normal)
        
        //Change the text inside text box with the selected option on segmented control
        welcomeText.text = greetingChoice.titleForSegmentAtIndex(greetingChoice.selectedSegmentIndex)! + " everyone"
        
        //display image on button click
        buttonImg.image = UIImage(named: "new-google.jpg")
        
        
    }
    
}

