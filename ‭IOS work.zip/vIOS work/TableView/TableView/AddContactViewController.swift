//
//  AddContactViewController.swift
//  TableView
//
//  Created by  on 10/20/16.
//  Copyright © 2016 UHCL. All rights reserved.
//

import UIKit

class AddContactViewController: UIViewController {

    
    @IBOutlet weak var firstTextField: UITextField!
    
    
    @IBOutlet weak var lastTextField: UITextField!
    
    @IBOutlet weak var phoneTextField: UITextField!
    
    @IBOutlet weak var emailTextField: UITextField!
    
    
    @IBOutlet weak var addressTextField: UITextView!
    
    var contact = Contact()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        contact = Contact(fname: firstTextField.text!, lname: lastTextField.text!,
                          phone: phoneTextField.text!,
                          email: emailTextField.text!,
                          address: addressTextField.text!)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
