//
//  contact.swift
//  TableView
//
//  Created by  on 10/4/16.
//  Copyright © 2016 UHCL. All rights reserved.
//

import Foundation

class Contact {

    var fname:String
    var lname:String
    var phone:String
    var email:String
    var address:String
    
    
    init(){
    
        fname = ""
        lname = ""
        phone = ""
        email = ""
        address = ""
    }
    
    init(fname : String, lname : String, phone : String, email : String, address : String){
        self.fname = fname
        self.lname = lname
        self.phone = phone
        self.email = email
        self.address = address
    }
    
    func fullName() -> String{
        return fname + " " + lname
    }
    
    func contactInfo() -> String{
        return "Name:" + fullName() + "\n" + "Phone:" + phone + "\n" + "Email:" + email + "\n" + "Address" + address
    }
    
}