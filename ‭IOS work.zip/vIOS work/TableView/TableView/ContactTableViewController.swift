//
//  ViewController.swift
//  TableView
//
//  Created by  on 10/4/16.
//  Copyright © 2016 UHCL. All rights reserved.
//

import UIKit

class ContactTableViewController: UITableViewController {
    
    
    var contacts: ContactDBModel!
    
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int{
        return 1 //one section
    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "My Contacts"
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count()
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let contactIdentifier = "ContactCell"
        //check to see if reusable cell exists first and use it
        let cell = tableView.dequeueReusableCellWithIdentifier(contactIdentifier, forIndexPath: indexPath)
        let contact = contacts.contactAtIndex(indexPath.row)
        
        cell.textLabel!.text = contact.fullName()
        
        cell.detailTextLabel!.text = "\(contact.email)"
        
        //default image for all cells
        cell.imageView!.image = UIImage(named: "img1.jpg")
        //UIImage(named: arrayofpictures[indexPath.row])
        
        return cell
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if let id = segue.identifier{
            switch id{
                case "ContactDetail":
                    if let contactDVC = segue.destinationViewController as? ContactDetailViewController { // refering to the new controller named ContactDetailViewController
                        let selectedRow = self.tableView.indexPathForSelectedRow?.row
                        contactDVC.contact = contacts.contactAtIndex(selectedRow!)
                }
            default:
                break
            }
        }
    }
    
    // From 3rd MVC
    @IBAction func save(segue: UIStoryboardSegue){
        if segue.identifier == "SaveUnwindSegue"{
            let dest = segue.sourceViewController as! AddContactViewController
            contacts.addContacts(dest.contact)
            tableView.reloadData()
        }
    }
    
    // From 3rd MVC
    @IBAction func calcel(segue: UIStoryboardSegue){
        dismissViewControllerAnimated(true, completion: nil)
    }
    
//    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//        let contact = contacts.contactAtIndex(indexPath.row)
//        let alert = UIAlertController(title:contact.fullName(),
//                                      message:contact.contactInfo(),
//                                      preferredStyle: .Alert
//                                      )
//        alert.addAction(UIAlertAction(title:"Close", style: .Default, handler: {_ in}))
//        self.presentViewController(alert, animated: true, completion: {})
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        contacts = ContactDBModel()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

