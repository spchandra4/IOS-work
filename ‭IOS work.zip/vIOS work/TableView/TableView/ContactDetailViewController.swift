//
//  ContactDetailViewController.swift
//  TableView
//
//  Created by  on 10/18/16.
//  Copyright © 2016 UHCL. All rights reserved.
//

import UIKit

class ContactDetailViewController: UIViewController {
    
    
    @IBOutlet weak var fname: UITextField!
    
    @IBOutlet weak var lname: UITextField!
    
    
    @IBOutlet weak var phone: UITextField!
    
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var address: UITextView!
    
    var contact = Contact()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        fname.text = contact.fname
        lname.text = contact.lname
        phone.text = contact.phone
        email.text = contact.email
        address.text = contact.address
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
