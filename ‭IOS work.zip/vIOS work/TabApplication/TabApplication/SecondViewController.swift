//
//  SecondViewController.swift
//  TabApplication
//
//  Created by  on 11/3/16.
//  Copyright © 2016 UHCL. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    var second = 20
    
    override func viewDidAppear(animated: Bool) {
        print("The value of second \(second)")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tab1 = self.tabBarController?.viewControllers?[0] as! FirstViewController
        
        let del = UIApplication.sharedApplication().delegate as! AppDelegate
        
        print(tab1.first.description)
        print("The integer is \(del.integer)")
        del.integer = 50000
        print("the value of second \(second)")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

