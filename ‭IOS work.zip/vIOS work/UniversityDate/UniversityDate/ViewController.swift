//
//  ViewController.swift
//  UniversityDate
//
//  Created by  on 9/20/16.
//  Copyright © 2016 UHCL. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var theMessage: UILabel!
    @IBOutlet weak var theDate: UIDatePicker!
    
    
    @IBOutlet weak var universityChoice: UIPickerView!
    
    var selectedRow = 0
    
    
    
    @IBAction func changeMessage(sender: UIDatePicker) {
        theMessage.text = values[selectedRow] + " " + String(theDate.date)
    }
    
    // get it from any database
    var values = ["uhcl", "uh", "uhd", "uhv", "rice", "tsu", "st. Thomas", "san jac", "hcc", "alvin"]
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        theDate.hidden = true
        self.universityChoice.dataSource = self
        self.universityChoice.delegate = self
    }

    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return values.count
    }
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return values[row]
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        theMessage.text = values[row] + " " + String(theDate.date)
        selectedRow = row
    }
    

}

