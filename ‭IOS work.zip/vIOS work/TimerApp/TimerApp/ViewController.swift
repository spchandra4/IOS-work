//
//  ViewController.swift
//  TimerApp
//
//  Created by  on 10/27/16.
//  Copyright © 2016 UHCL. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var currentLabel: UILabel!
    var timer = NSTimer()
    var counter = 0
    let timeInterval = 0.1
    var firsttime = true
    
    
    @IBAction func play(sender: UIBarButtonItem) {
        if firsttime {
            sleep(1)
            firsttime = false
        }
        timer = NSTimer.scheduledTimerWithTimeInterval(timeInterval, target: self, selector: #selector(ViewController.updateCounter), userInfo: nil, repeats: true)
        NSRunLoop.mainRunLoop().addTimer(timer, forMode: NSDefaultRunLoopMode)
        timer.fire()
    }
    func updateCounter(){
        currentLabel.text = String(counter)
        counter += 1
    }
    
    
    @IBAction func pause(sender: UIBarButtonItem) {
        timer.invalidate()
        
    }
    
    
    @IBAction func clear(sender: UIBarButtonItem) {
        timer.invalidate()
        counter = 0
        currentLabel.text = "0"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

